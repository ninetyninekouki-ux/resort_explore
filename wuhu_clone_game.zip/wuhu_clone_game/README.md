# Wuhu Clone Game (Unity prototype)

このフォルダーはUnityで『パイロットウイングスリゾート』風のフライト探索ゲームを構築するためのプロトタイプです。島の形やランドマークはオリジナルからインスパイアされた構造を意識しつつ、自作のオブジェクトと地形を使って構築してください。

## 構成

```
wuhu_clone_game/Assets/
├─ Scenes/           # シーンファイルを格納（未作成）
├─ Scripts/          # 飛行体やゲームシステムのスクリプト
│  ├─ AircraftBase.cs
│  ├─ JetpackController.cs
│  ├─ PlaneController.cs
│  ├─ HangGliderController.cs
│  ├─ GameModeManager.cs
│  ├─ MapManager.cs
│  └─ IPoint.cs
└─ ...               # モデルやUI等を追加予定
```

## 簡易説明

- `AircraftBase` は全ての飛行体の基底クラスで、速度・揚力・抗力の簡単な物理処理を共通化しています。
- `JetpackController`、`PlaneController`、`HangGliderController` はそれぞれジェットパック、飛行機、ハンググライダーの挙動を実装しています。
- `GameModeManager` は自由飛行とミッションモード間のシーン切り替えを管理します。
- `IPoint` はマップ上のランドマークで、プレイヤーが接触すると収集され、イベントが発火します。
- `MapManager` はランドマークの収集数を管理し、UIを更新します。

## 使用方法

1. Unity Editor でこのプロジェクトを開きます。
2. `Assets/Scenes` 内に新規シーンを作成し、必要なGameObject（飛行機、カメラ、地形、UIキャンバスなど）を配置します。
3. プレイヤーオブジェクトに `Rigidbody` と任意のコントローラ (`JetpackController` など) を追加し、タグを `Player` に設定します。
4. 地形上に `IPoint` コンポーネントを持つオブジェクトを配置してランドマークを設定します。
5. `MapManager` をシーンに配置し、UIテキストを参照として割り当てます。
6. 入力設定は Unity のデフォルトの Input Manager または新しい Input System で `Horizontal`、`Vertical`、`Mouse X`、`Mouse Y` を設定してください。

## GitHubへのアップロードについて

このディレクトリはまだGit管理されていません。GitHub上の既存リポジトリに追加したい場合は、リポジトリ名を指定するか、ご自身でローカルリポジトリを初期化してプッシュしてください。本環境からは既存リポジトリへのコミット操作は可能ですが、新規リポジトリの作成はサポートしていません。