using UnityEngine;

/// <summary>
/// Abstract base class for all flyable vehicles.
/// Provides common parameters and simple flight physics.
/// </summary>
public abstract class AircraftBase : MonoBehaviour
{
    [Header("Flight parameters")]
    public float maxSpeed = 20f;
    public float acceleration = 5f;
    public float rotationSpeed = 45f;
    public float liftCoefficient = 0.5f;
    public float dragCoefficient = 0.02f;

    protected float currentSpeed;
    protected Rigidbody rb;

    protected virtual void Awake()
    {
        rb = GetComponent<Rigidbody>();
        // Configure rigidbody defaults for flying objects
        if (rb != null)
        {
            rb.useGravity = false;
            rb.drag = 0f;
            rb.angularDrag = 0.1f;
        }
    }

    protected virtual void Update()
    {
        HandleInput();
    }

    protected virtual void FixedUpdate()
    {
        ApplyPhysics();
    }

    /// <summary>
    /// Reads input axes and adjusts currentSpeed/rotation accordingly.
    /// Derived classes should override to implement specific controls.
    /// </summary>
    protected abstract void HandleInput();

    /// <summary>
    /// Applies thrust, lift and drag forces to the rigidbody.
    /// Derived classes can extend this to add vehicle specific behaviour.
    /// </summary>
    protected virtual void ApplyPhysics()
    {
        if (rb == null) return;

        // Move forward based on currentSpeed
        Vector3 forward = transform.forward * currentSpeed;

        // Compute lift: proportional to speed squared and lift coefficient
        float lift = liftCoefficient * currentSpeed * currentSpeed;
        Vector3 liftForce = transform.up * lift;

        // Compute drag: oppose forward motion
        float drag = dragCoefficient * currentSpeed * currentSpeed;
        Vector3 dragForce = -transform.forward * drag;

        // Apply forces
        rb.AddForce(forward + liftForce + dragForce, ForceMode.Force);
    }
}