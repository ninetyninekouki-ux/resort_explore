using UnityEngine;

/// <summary>
/// Represents an information point (landmark) that can be collected in free flight.
/// When the player enters the trigger, it marks as collected and triggers an event.
/// </summary>
[RequireComponent(typeof(Collider))]
public class IPoint : MonoBehaviour
{
    public string landmarkId;
    [Tooltip("Display name shown to the player when discovered.")]
    public string landmarkName;
    [Tooltip("Description shown when discovered.")]
    [TextArea]
    public string description;
    public bool collected;

    public delegate void LandmarkCollectedHandler(IPoint point);
    public static event LandmarkCollectedHandler OnLandmarkCollected;

    private void Awake()
    {
        // Ensure this collider is a trigger
        Collider col = GetComponent<Collider>();
        col.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (collected) return;
        // Check if the entering object is the player
        if (other.CompareTag("Player"))
        {
            collected = true;
            OnLandmarkCollected?.Invoke(this);
        }
    }
}