using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Manages collection of landmarks and updates UI counters accordingly.
/// Attach to an object in the scene and assign UI references.
/// </summary>
public class MapManager : MonoBehaviour
{
    public Text landmarkCounterText;
    public Text messageText;
    private int totalLandmarks;
    private int collectedCount;

    private void OnEnable()
    {
        IPoint.OnLandmarkCollected += HandleLandmarkCollected;
    }

    private void OnDisable()
    {
        IPoint.OnLandmarkCollected -= HandleLandmarkCollected;
    }

    private void Start()
    {
        // Count total landmarks present in scene
        totalLandmarks = FindObjectsOfType<IPoint>().Length;
        UpdateCounterText();
    }

    private void HandleLandmarkCollected(IPoint point)
    {
        collectedCount++;
        UpdateCounterText();
        if (messageText != null)
        {
            messageText.text = $"{point.landmarkName} を発見！\n{point.description}";
        }
    }

    private void UpdateCounterText()
    {
        if (landmarkCounterText != null)
        {
            landmarkCounterText.text = $"{collectedCount} / {totalLandmarks}";
        }
    }
}