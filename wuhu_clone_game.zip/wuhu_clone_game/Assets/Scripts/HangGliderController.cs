using UnityEngine;

/// <summary>
/// Controller for a simple hang glider. The glider primarily maintains lift from forward movement and allows turning.
/// </summary>
public class HangGliderController : AircraftBase
{
    [Header("Glider settings")]
    public float glideSpeed = 15f;
    public float turnSpeed = 25f;
    public float liftMultiplier = 1.2f;

    protected override void HandleInput()
    {
        // Input for turning left/right
        float horizontal = Input.GetAxis("Horizontal");
        transform.Rotate(Vector3.up, horizontal * turnSpeed * Time.deltaTime);
        // Adjust speed gradually to glide speed
        currentSpeed = Mathf.MoveTowards(currentSpeed, glideSpeed, acceleration * Time.deltaTime);
        // Slight pitch control to climb or descend
        float pitchInput = -Input.GetAxis("Vertical");
        transform.Rotate(Vector3.right, pitchInput * rotationSpeed * Time.deltaTime);
    }

    protected override void ApplyPhysics()
    {
        if (rb == null) return;
        // Forward motion
        rb.AddForce(transform.forward * currentSpeed, ForceMode.Force);
        // Lift proportional to forward speed and lift multiplier
        float lift = liftCoefficient * currentSpeed * liftMultiplier;
        rb.AddForce(transform.up * lift, ForceMode.Force);
        // Drag to simulate gliding resistance
        rb.AddForce(-rb.velocity.normalized * dragCoefficient * currentSpeed * currentSpeed, ForceMode.Force);
    }
}