using UnityEngine;

/// <summary>
/// Simple controller for a small plane. Forward motion is mostly automatic, with pitch and roll controlled by the player.
/// </summary>
public class PlaneController : AircraftBase
{
    [Header("Plane settings")]
    public float thrust = 50f;
    public float pitchRate = 25f;
    public float rollRate = 35f;
    public float yawRate = 20f;

    protected override void HandleInput()
    {
        // Read mouse or controller input for pitch and yaw
        float pitchInput = -Input.GetAxis("Mouse Y");
        float yawInput = Input.GetAxis("Mouse X");
        float rollInput = 0f;
        if (Input.GetKey(KeyCode.A)) rollInput = 1f;
        if (Input.GetKey(KeyCode.D)) rollInput = -1f;

        // Rotate the aircraft
        transform.Rotate(Vector3.right, pitchInput * pitchRate * Time.deltaTime);
        transform.Rotate(Vector3.forward, rollInput * rollRate * Time.deltaTime);
        transform.Rotate(Vector3.up, yawInput * yawRate * Time.deltaTime);

        // Clamp pitch to avoid flipping fully upside-down (optional)
        Vector3 euler = transform.eulerAngles;
        euler.x = Mathf.Clamp((euler.x > 180f ? euler.x - 360f : euler.x), -80f, 80f);
        transform.eulerAngles = new Vector3(euler.x, euler.y, euler.z);

        // Increase speed gradually up to maxSpeed
        currentSpeed = Mathf.MoveTowards(currentSpeed, maxSpeed, acceleration * Time.deltaTime);
    }

    protected override void ApplyPhysics()
    {
        if (rb == null) return;
        // Forward thrust
        rb.AddForce(transform.forward * thrust, ForceMode.Force);
        // Slight upward lift to counter gravity proportional to speed
        float lift = liftCoefficient * currentSpeed;
        rb.AddForce(transform.up * lift, ForceMode.Force);
        // Dampen drag
        float dragForce = dragCoefficient * currentSpeed * currentSpeed;
        rb.AddForce(-rb.velocity.normalized * dragForce, ForceMode.Force);
    }
}