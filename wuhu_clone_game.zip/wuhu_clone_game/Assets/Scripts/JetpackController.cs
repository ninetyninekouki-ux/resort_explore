using UnityEngine;

/// <summary>
/// Controller for jetpack-type flight.
/// Provides omnidirectional thrust controlled by the player and manages fuel.
/// </summary>
public class JetpackController : AircraftBase
{
    [Header("Jetpack settings")]
    public float jetForce = 30f;
    public float maxFuel = 100f;
    public float fuelBurnRate = 20f;
    public float fuelRecoveryRate = 10f;

    private float currentFuel;

    protected override void Awake()
    {
        base.Awake();
        currentFuel = maxFuel;
    }

    /// <summary>
    /// Handles WASD/Space/LeftShift input to control thrust direction.
    /// </summary>
    protected override void HandleInput()
    {
        // Forward/backward/lateral movement adjusts currentSpeed (for horizontal translation)
        float horizontal = Input.GetAxis("Horizontal"); // A/D or left/right
        float vertical = Input.GetAxis("Vertical");   // W/S or forward/back

        // Adjust rotation based on mouse input
        float yaw = Input.GetAxis("Mouse X");
        float pitch = -Input.GetAxis("Mouse Y");
        transform.Rotate(Vector3.up, yaw * rotationSpeed * Time.deltaTime);
        transform.Rotate(Vector3.right, pitch * rotationSpeed * Time.deltaTime);

        // Compute local movement vector (no up/down for this axis)
        Vector3 moveDir = new Vector3(horizontal, 0f, vertical);
        if (moveDir.sqrMagnitude > 1f) moveDir.Normalize();

        // Adjust speed relative to input
        currentSpeed = Mathf.MoveTowards(currentSpeed, moveDir.z * maxSpeed, acceleration * Time.deltaTime);

        // Thrust upward/downward
        float up = 0f;
        if (Input.GetKey(KeyCode.Space)) up += 1f;
        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) up -= 1f;

        // Apply jet thrust if there is fuel
        if (up != 0f && currentFuel > 0f)
        {
            Vector3 thrust = transform.up * up * jetForce;
            rb.AddForce(thrust, ForceMode.Force);
            currentFuel = Mathf.Max(0f, currentFuel - fuelBurnRate * Time.deltaTime);
        }
        else
        {
            // Passive fuel recovery when not thrusting
            currentFuel = Mathf.Min(maxFuel, currentFuel + fuelRecoveryRate * Time.deltaTime);
        }
    }

    /// <summary>
    /// Extends base physics to apply forward translation.
    /// </summary>
    protected override void ApplyPhysics()
    {
        base.ApplyPhysics();
        // Forward translation (apply as force in FixedUpdate)
        if (rb != null)
        {
            Vector3 forward = transform.forward * currentSpeed;
            rb.velocity = new Vector3(forward.x, rb.velocity.y, forward.z);
        }
    }

    /// <summary>
    /// Expose fuel amount for UI purposes.
    /// </summary>
    public float GetFuelFraction()
    {
        return maxFuel > 0f ? currentFuel / maxFuel : 0f;
    }
}