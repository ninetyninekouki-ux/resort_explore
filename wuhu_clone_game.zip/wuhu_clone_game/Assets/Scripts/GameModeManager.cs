using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Simple manager for switching between free flight and mission modes.
/// Attach to a persistent game object in the initial scene.
/// </summary>
public class GameModeManager : MonoBehaviour
{
    public enum GameMode { FreeFlight, Mission }

    public GameMode currentMode = GameMode.FreeFlight;

    public string freeFlightScene = "FreeFlight";
    public string missionScene = "Mission";

    public void StartFreeFlight()
    {
        currentMode = GameMode.FreeFlight;
        SceneManager.LoadScene(freeFlightScene);
    }

    public void StartMission()
    {
        currentMode = GameMode.Mission;
        SceneManager.LoadScene(missionScene);
    }
}